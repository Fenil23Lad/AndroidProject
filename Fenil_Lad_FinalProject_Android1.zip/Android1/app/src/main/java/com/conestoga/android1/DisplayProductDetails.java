package com.conestoga.android1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DisplayProductDetails extends AppCompatActivity {
    TextView txtproductName;
    TextView txtPrice;
    ImageView imgProduct;
    TextView productDescription;
    EditText edittxtQuantiy;
    private int[] images={
            R.drawable.image1,R.drawable.image2,R.drawable.image3,R.drawable.image4,
            R.drawable.image5,R.drawable.image6,R.drawable.image7

    };
    //array for product price
    private String[] price={"$120","$150","$220","$95","$80" ,"$175","$300"};
    //array for description
    private String[] product_description={
            "Car 1",
            "Car 2",
            "Car 3",
            "Car 4",
            "Car 5",
            "Car 6",
            "Car 7",
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Button btnBack;
        Button btnOrder;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_product_details);
        txtproductName = (TextView) findViewById(R.id.txtProductName);
        imgProduct=(ImageView)findViewById(R.id.imageViewProduct);
        productDescription=(TextView) findViewById(R.id.textViewDescription);
//        txtPrice=(TextView)findViewById(R.id.textViewPrice);
       // edittxtQuantiy=(EditText)findViewById(R.id.editTextQuantity);
        int imageid=getIntent().getIntExtra("ImageId",0);
        txtproductName.setText((getIntent().getStringExtra("productitemtext")));
        //setting images by getting position  'imageid'
        imgProduct.setImageResource(images[imageid]);
//        txtPrice.setText(price[imageid]);
        //setting description by getting position  'imageid'
        productDescription.setText(product_description[imageid]);

        btnBack=findViewById(R.id.btnback);
        btnOrder=findViewById(R.id.btnOrder);
        //on back buutton navigates to product page
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(DisplayProductDetails.this,displayProduct.class);
                startActivity(intent);


            }
        });

        //on order click navigates to thankyou page
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edittxtQuantiy.getText().toString().matches(""))
                {
                    Toast.makeText(DisplayProductDetails.this,"Please Enter Quantity",Toast.LENGTH_LONG).show();
                }
                else {
                    Intent intent = new Intent(DisplayProductDetails.this, thankyou.class);
                }
            }
        });



    }
}