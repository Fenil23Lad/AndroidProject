package com.conestoga.android1;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signin extends AppCompatActivity {

    DatabaseHelper mDatabaseHelper1;
    private Button btnSubmit;
    private EditText editText1,editText2;
    TextView email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

//        textview for email
        editText1 = (EditText) findViewById(R.id.editText8);

//        textview for password
        editText2 = (EditText) findViewById(R.id.editText9);

//        button submit
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

//        for display email on login
        email=(TextView)findViewById(R.id.editText8);
        mDatabaseHelper1 = new DatabaseHelper(this);


//        Activity on buttonClick
        btnSubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String newEntry1 = editText1.getText().toString();
                String newEntry2 = editText2.getText().toString();

//                Check empty fields
                if (newEntry1.equals("")|| newEntry2.equals("")){
                    toastMessage("Field is empty");
                }
                else {
                    Boolean checkmail1 = mDatabaseHelper1.checkmail1(newEntry1);
                    if(checkmail1 == true){
                        btnSubmit.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                Intent i = new Intent(signin.this,MainActivity.class);
                                i.putExtra("email",email.getText().toString().trim());
                                startActivity(i);
                            }
                        });
                    }
                    else{
                        toastMessage("Email not registred");
                    }
                }
            }
        });
    }

    public void toastMessage(String message) {
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
