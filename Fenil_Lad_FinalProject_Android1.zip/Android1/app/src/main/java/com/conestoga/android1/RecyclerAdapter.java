package com.conestoga.android1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder> {
//globally declaring images array in class
    private int[] images;

    private List<String> list;
    //creating constructor to get images and list from product class
    public RecyclerAdapter(int [] images, List<String> list){
        this.images=images;
        this.list=list;
    }




    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflating the products_layout
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.products_layout,parent,false);
        ImageViewHolder imageViewHolder=new ImageViewHolder(view);
        return imageViewHolder;
    }

//binding the data to imageview and textview
    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        int image_ID=images[position];
        holder.imgViewProducts.setImageResource(image_ID);
        holder.txtProductTitle.setText(list.get(position));
    }
    //counting images length
    @Override
    public int getItemCount() {
        return images.length;

    }



//declaring new class to get images and textview instances and working with click listener
    public static class ImageViewHolder extends RecyclerView.ViewHolder implements
            View.OnClickListener {
        private  Context context;
        ImageView imgViewProducts;
        TextView txtProductTitle;



        public ImageViewHolder(@NonNull View v) {
            super(v);
            v.setOnClickListener(this);
            imgViewProducts=v.findViewById(R.id.imageViewProducts);
            txtProductTitle=v.findViewById(R.id.txtProductTitle);

            context=v.getContext();
        }
//on click of text navigating to display page with the position and text clicked;
        public void onClick (View view) {
            int pos = getLayoutPosition();

            String currentItem=SingleItemClick(pos);
            Intent intent=new Intent(context,DisplayProductDetails.class);

            intent.putExtra("productitemtext", currentItem);
            intent.putExtra("ImageId",pos);

            context.startActivity(intent);
        }

        //getting currentitem of text clicked

        private String SingleItemClick(int pos) {

            String currentItem = txtProductTitle.getText().toString();
            return currentItem;



        }


    }
}
