package com.conestoga.android1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private  static final String TAG = "DatabaseHelper";
    private  static final String TABLE_NAME = "user_table";
    private  static final String COL1 = "email";
    private  static final String COL2 = "password";

    public DatabaseHelper(@Nullable Context context) {
        super(context, TABLE_NAME, null, 1);
    }

//    Query-1 Create query
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable =  "CREATE TABLE " + TABLE_NAME + "(email TEXT PRIMARY KEY," +
                COL2 +" PASSWORD)";
        db.execSQL(createTable);
    }

    // Query-2 Upgrade Query
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Query-3 Insert Data into Table
    public boolean addData(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email",email);
        contentValues.put("password",password);

        Log.e(TAG,"add new data: " + email + "to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME,null,contentValues);

        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

    // Query-4 Check email if it exists or not
    public boolean checkmail(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE EMAIL = ?",new String[]{email});
        if(cursor.getCount()>0) return false;
        else return true;
    }

    // Query-5 Check email if it exists or not
    public boolean checkmail1(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE EMAIL = ?",new String[]{email});
        if(cursor.getCount()>0) return true;
        else return false;
    }

}

