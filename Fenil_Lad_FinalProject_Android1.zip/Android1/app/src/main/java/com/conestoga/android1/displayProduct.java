package com.conestoga.android1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.Arrays;
import java.util.List;

public class displayProduct extends AppCompatActivity {


    private RecyclerView recyclerView;
    //array of Images
    private int[] images={
            R.drawable.image1,R.drawable.image2,R.drawable.image3,R.drawable.image4,
            R.drawable.image5,R.drawable.image6,R.drawable.image7

    };

    private List<String> list;



    private  RecyclerAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private DisplayProductDetails displayproduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_product);

        recyclerView=findViewById(R.id.recyclerview);
        layoutManager=new GridLayoutManager(this,2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        //getting the string  array from strings.xml
        list= Arrays.asList(getResources().getStringArray(R.array.product_names));
        //passing images and names of product in list to adapter
        adapter=new RecyclerAdapter(images,list);
        recyclerView.setAdapter(adapter);

    }
}
