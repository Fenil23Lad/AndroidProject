package com.conestoga.android1;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signup1 extends AppCompatActivity {

    DatabaseHelper mDatabaseHelper;
    private Button btnAdd;
    private EditText editText2,editText3,editText4;
    private TextView text11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_signup1);

        //        textview for email
        editText2 = (EditText) findViewById(R.id.editText2);

        //        textview for password
        editText3 = (EditText) findViewById(R.id.editText3);

        //        textview for confirm pasword
        editText4 = (EditText) findViewById(R.id.editText4);

        //        button for register
        btnAdd = (Button) findViewById(R.id.button3);
        mDatabaseHelper = new DatabaseHelper(this);

        text11 = (TextView) findViewById(R.id.textView11);

        text11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(signup1.this,signin.class);
                startActivity(i);
            }
        });

//        onclick of button
        btnAdd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String newEntry1 = editText2.getText().toString();
                String newEntry2 = editText3.getText().toString();
                String newEntry3 = editText4.getText().toString();

//                check Validations
                if (newEntry1.equals("")|| newEntry2.equals("") || newEntry3.equals("")){
                    toastMessage("Field empty");
                }
                else {
                    if(newEntry2.equals(newEntry3)){
                        Boolean checkmail = mDatabaseHelper.checkmail(newEntry1);
                        if(checkmail == true){
                            Boolean insert = mDatabaseHelper.addData(newEntry1,newEntry2);
                            if(insert == true){
                                toastMessage("Successfully registred");
                                editText2.setText("");
                                editText3.setText("");
                                editText4.setText("");
                            }
                        }
                        else{
                            toastMessage("Email already exists");
                        }
                    }
                    else{
                        toastMessage("Password do not match");
                    }
                }
            }
        });
    }
    public void toastMessage(String message) {
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}

